import 'package:take_out_app/constants/imports.dart';

class SearchFeild extends StatelessWidget {
  const SearchFeild({required this.onChanged});
  final void Function(String) onChanged;
  @override
  Widget build(BuildContext context) {
    return TextFormField(
      onChanged: onChanged,
      cursorColor: kDeepGrey,
      decoration: InputDecoration(
        hintText: 'Pizza',
        hintStyle: TextStyle(color: kDeepGrey, fontSize: getWidth(13.0)),
        prefixIcon: Padding(
          child: SvgPicture.asset(
            "assets/icons/search.svg",
            color: kDeepGrey,
            height: getHeight(14.36),
            width: getWidth(14.36),
          ),
          padding:
              EdgeInsets.only(left: getWidth(10.0), right: getWidth(15.0)),
        ),
        prefixIconConstraints: BoxConstraints(),
        suffixIcon: Padding(
          child: SvgPicture.asset(
            'assets/icons/voice_search.svg',
            color: kDeepGrey,
            height: 14.36,
            width: 14.36,
          ),
          padding: EdgeInsets.only(right: getWidth(10.0)),
        ),
        suffixIconConstraints: BoxConstraints(),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(getWidth(10.0)),
          borderSide: BorderSide.none,
        ),
        fillColor: kFilledField,
        constraints: BoxConstraints(),
        contentPadding: EdgeInsets.symmetric(horizontal: getWidth(10.0)),
        filled: true,
      ),
    );
  }
}
