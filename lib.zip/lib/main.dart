import 'package:flutter/material.dart';
import 'package:take_out_app/screens/restaurant_item.dart';
import 'package:take_out_app/screens/restaurant_overview.dart';
import 'package:take_out_app/screens/search_result.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Take-Out App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: RestaurantOverview(),
    );
  }
}
