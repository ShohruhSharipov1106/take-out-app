import 'dart:io';

import 'package:flutter/material.dart';

const Color kRed = Color(0xffE92F48);
const Color kBlack = Color(0xff424242);
const Color kDeepGrey = Color(0xff7E8389);
const Color kYellowDragon = Color(0xffFFC107);
const Color kSilverSycee = Color(0xffA0A8B1);
const Color kBronze = Color(0xffD97953);
const Color kGreen = Color(0xff1EE76E); //to'g'ri javob uchun rang
const Color kBrown = Color(0xff741C28); //xato javob uchun rang
const Color kFilledField =
    Color(0xffF2F2F2); //input field ichini to'ldiradigan rang

const Color kLightGrey = Color(0xffF0F0F0);
const Color kUnSelectedText = Color(0xffC4C4C4);
