import 'package:take_out_app/constants/imports.dart';
import 'package:take_out_app/search_field.dart';

class SearchResult extends StatefulWidget {
  @override
  _SearchResultState createState() => _SearchResultState();
}

List<String> imgs = [
  "https://s3-alpha-sig.figma.com/img/0e3f/8b16/02c59c86a80f2b5b22bc28134566404b?Expires=1639353600&Signature=EAQIEgePCa7F9iS0LGInDkK99AmdbDCnm-bhfP5gPLBq9AgW-PafL9dQD7WszqIZBAZIVTk77Iy6JO4EL0ZvAXgED1WChRlB4R6WKDrTWEFxq0kPLKNCpouOhDlTis4V8Z5voR8O3IVeX96tWnu2v3y7qv~~d-Jtm3-oaQ0pcEJBiWcoLfE~GBjLZ7Md70Rkw9DIGX7o1ipVPv5tvWRl4GaLALgSUs-W0h00HXy7Fi1AQ09gK0xNwM5TrGPWkvrR--3RG9D9qZ1QShQn6PUTsSG7frwr7kPPCzVRSGNRN6CeU6sJ81RqeTc1u7uyCUL2BvGgbvQo2MBKLIExYDuelA__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
  "https://s3-alpha-sig.figma.com/img/a4d0/da38/b57fa920360255e56b601b806af13277?Expires=1639353600&Signature=IYwK9fEhxzzKcLGZjbGVRGhEXKaNF9Oc73sFl8AbnXfpTWTfHGh22PSOodoDDiehsIAB33OYSDsTuDcNMi0fIXprlC2S4OhftcKjl2Mw920~wLFiU5pMuxSh62RFpkQ9ko2cNX2gTppsE-ZEcDu4fpiXaZDqVTxGKH00J528OWhPZSEE1~84rKfbfJdjocn1Bxy26-UyspFmaP7t7OCUGjJA2uwyVBgpj7SM1nFeBZtlWr4soJhQcFjvNI9qggmeQeZ5dnGF3to-SjYCogyI~hoMiWD6ps78B7DnA3PFm64jZ0siHXGmx5oJmx4auy-gmMldUcE6LZLY5UgnQy3lzw__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
  "https://s3-alpha-sig.figma.com/img/984f/09bd/8103570a69624eee2c496f668f33cb6d?Expires=1639353600&Signature=EZyXF2yiXL5CArhvd3FuB815zLlgJDbYp-p-7PyiyefHhFzzbr65bFMwWDag0gKle-lBpGwCTqMf0fHdYdYf61hWSNUCnBgbKBFCOkVk~jHSN4W9QxRlU52Mq-Q5ceqHhQyMRu83rCDIob3INNb6~lFwtxgcS2Dic7yMIGUsAcc6FMgm8KvoQf~0nIklaM0NHG0acngMd7nNBUVPDNS3WWZ94T~CZv3iUyHYeCt6ZJJv1dCbm6Qgz5hk6yF2i7I7BEQ18-EHtjuhScUb05XBSv7l~hWKcx2pps8-n0NpifRgzGav-HXamWZMn3yklRG1tmqo~unE8vNt51VlLXeeQQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
];
List<String> foodTitles = [
  "Roberta's",
  "Juliana’s Pizza",
  "Joe's Pizza",
];
List<String> nationals = [
  "Italian",
];
List<String> foods = [
  "Pizza",
];
List<String> deliveryTimes = [
  "15-20",
  "12-15",
  "10-15",
];
List<double> deliveryPrices = [
  1.99,
];
List<double> ratings = [
  4.7,
  4.9,
  4.6,
];

class _SearchResultState extends State<SearchResult> {
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.white,
        shadowColor: kFilledField,
        elevation: 0.5,
        title: const Text(
          "Search",
          style: TextStyle(
            fontSize: 20.0,
            fontWeight: FontWeight.w400,
            color: kDeepGrey,
          ),
        ),
        centerTitle: true,
        leadingWidth: getWidth(50.0),
        leading: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            InkWell(
              onTap: () {
                Navigator.pop(context);
              },
              child: SvgPicture.asset(
                "assets/icons/back.svg",
                height: getHeight(12.39),
                width: getWidth(18.0),
                fit: BoxFit.cover,
                color: kDeepGrey,
              ),
            ),
          ],
        ),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(
          horizontal: getWidth(20.0),
          vertical: getHeight(20.0),
        ),
        child: Column(
          children: [
            // Search Field

            Row(
              children: [
                Container(
                  height: getHeight(45.0),
                  width: getWidth(283.00),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    color: kFilledField,
                  ),
                  child: SearchFeild(onChanged: (v) {}),
                ),
                SizedBox(width: getWidth(15.0)),

                // Search Filter

                InkWell(
                  onTap: () {},
                  child: Container(
                    height: getHeight(45.0),
                    width: getWidth(37.00),
                    padding: EdgeInsets.symmetric(
                      horizontal: getWidth(10.0),
                      vertical: getHeight(10.0),
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: kFilledField,
                    ),
                    child: SvgPicture.asset(
                      "assets/icons/Filter Icon.svg",
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: getHeight(30.0)),

            // Restaurant cards

            SizedBox(
              height: getHeight(610.0),
              child: ListView.builder(
                itemBuilder: (context, index) {
                  return _restaurantCard(
                    imgs[index],
                    foodTitles[index],
                    nationals[0],
                    foods[0],
                    deliveryTimes[0],
                    deliveryPrices[0],
                    ratings[index],
                  );
                },
                itemCount: foodTitles.length,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Container _restaurantCard(
    String img,
    String foodTitle,
    String national,
    String food,
    String deliveryTime,
    double deliveryPrice,
    double rating,
  ) {
    return Container(
      height: getHeight(218.0),
      width: getWidth(335.0),
      margin: EdgeInsets.only(bottom: getHeight(20.5)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                image: DecorationImage(
                  image: NetworkImage(
                    img,
                  ),
                  fit: BoxFit.cover,
                )),
            height: getHeight(150.0),
            width: getWidth(335.0),
          ),
          SizedBox(height: getHeight(8.0)),
          Text(
            foodTitle,
            style: const TextStyle(
              fontSize: 22.0,
              fontWeight: FontWeight.w600,
              color: kDeepGrey,
            ),
          ),
          Text(
            national +
                " • " +
                food +
                "\n" +
                deliveryTime +
                " min • " +
                "\$$deliveryPrice Delivery • " +
                "☆$rating",
            style: const TextStyle(
              fontSize: 12.0,
              fontWeight: FontWeight.w400,
              color: kDeepGrey,
            ),
          ),
        ],
      ),
    );
  }
}
